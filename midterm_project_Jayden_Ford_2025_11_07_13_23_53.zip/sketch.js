function setup() {
  createCanvas(400, 400);
}

function draw() {
  background(220);
}
let player;
let meteors = [];
let gameState = "start"; // "start", "play", "gameover"
let timer = 0;
let bestTime = 0;
let bgColors = ["#ff66cc", "#b266ff", "#6699ff", "#ffee66", "#ff6666"];
let currentColorIndex = 0;
let nextColorIndex = 1;
let colorLerpAmt = 0;
let speedMultiplier = 1.5;

function setup() {
  createCanvas(windowWidth, windowHeight);
  player = new Player();
  textAlign(CENTER, CENTER);
}

function draw() {
  // Background color transition
  let c1 = color(bgColors[currentColorIndex]);
  let c2 = color(bgColors[nextColorIndex]);
  let bg = lerpColor(c1, c2, colorLerpAmt);
  background(bg);
  colorLerpAmt += 0.002 * speedMultiplier;
  if (colorLerpAmt >= 1) {
    colorLerpAmt = 0;
    currentColorIndex = nextColorIndex;
    nextColorIndex = (nextColorIndex + 1) % bgColors.length;
  }

  // Twinkling stars
  drawStars();

  if (gameState === "start") {
    fill(255);
    textSize(80);
    text("🌌 Galaxy Dodge 🌌", width / 2, height / 2 - 100);
    textSize(32);
    text("Click to Start", width / 2, height / 2);
  } else if (gameState === "play") {
    player.update();
    player.show();

    // Spawn meteors
    if (frameCount % int(40 / speedMultiplier) === 0) {
      meteors.push(new Meteor());
    }

    // Update meteors
    for (let i = meteors.length - 1; i >= 0; i--) {
      meteors[i].update();
      meteors[i].show();
      if (meteors[i].offscreen()) meteors.splice(i, 1);
      else if (meteors[i].hits(player)) {
        gameState = "gameover";
        if (timer > bestTime) bestTime = timer;
        timer = 0;
      }
    }

    // Timer + score
    timer += deltaTime / 1000;
    fill(255);
    textSize(24);
    textAlign(LEFT);
    text("⏱ Time: " + timer.toFixed(2), 20, 30);
    text("🏆 Best: " + bestTime.toFixed(2), 20, 60);

  } else if (gameState === "gameover") {
    // Animated defeat screen
    fill(255, 50, 50);
    textSize(80);
    text("☠️ DEFEATED ☠️", width / 2, height / 2 - 100);
    fill(255);
    textSize(40);
    text("Try Again", width / 2, height / 2);
    textSize(24);
    text("Press X or Click to Restart", width / 2, height / 2 + 80);
  }
}

function mousePressed() {
  if (gameState === "start" || gameState === "gameover") {
    restartGame();
  }
}

function keyPressed() {
  if (gameState === "gameover" && key === 'x') {
    restartGame();
  }
}

function restartGame() {
  gameState = "play";
  meteors = [];
  timer = 0;
  player = new Player();
}

function drawStars() {
  noStroke();
  for (let i = 0; i < 100; i++) {
    fill(255, random(100, 255));
    ellipse(random(width), random(height), random(1, 3));
  }
}

// Player (astronaut)
class Player {
  constructor() {
    this.x = width / 2;
    this.y = height / 2;
    this.size = 40;
    this.speed = 5 * speedMultiplier;
  }

  update() {
    if (keyIsDown(LEFT_ARROW)) this.x -= this.speed;
    if (keyIsDown(RIGHT_ARROW)) this.x += this.speed;
    if (keyIsDown(UP_ARROW)) this.y -= this.speed;
    if (keyIsDown(DOWN_ARROW)) this.y += this.speed;
    this.x = constrain(this.x, this.size / 2, width - this.size / 2);
    this.y = constrain(this.y, this.size / 2, height - this.size / 2);
  }

  show() {
    // Astronaut stick figure
    stroke(255);
    strokeWeight(3);
    fill(200);
    ellipse(this.x, this.y - 20, 25); // helmet
    line(this.x, this.y - 10, this.x, this.y + 25); // body
    line(this.x, this.y, this.x - 15, this.y + 10); // left arm
    line(this.x, this.y, this.x + 15, this.y + 10); // right arm
    line(this.x, this.y + 25, this.x - 10, this.y + 45); // left leg
    line(this.x, this.y + 25, this.x + 10, this.y + 45); // right leg
  }
}

// Meteor
class Meteor {
  constructor() {
    this.r = random(20, 50);
    this.x = random([0 - this.r, width + this.r]);
    this.y = random(height);
    this.xspeed = random(-5, 5) * speedMultiplier;
    this.yspeed = random(-3, 3) * speedMultiplier;
  }

  update() {
    this.x += this.xspeed;
    this.y += this.yspeed;
  }

  show() {
    fill(255, 120, 0);
    noStroke();
    ellipse(this.x, this.y, this.r);
  }

  offscreen() {
    return (
      this.x < -this.r ||
      this.x > width + this.r ||
      this.y < -this.r ||
      this.y > height + this.r
    );
  }

  hits(player) {
    let d = dist(this.x, this.y, player.x, player.y);
    return d < this.r / 2 + player.size / 2;
  }
}
